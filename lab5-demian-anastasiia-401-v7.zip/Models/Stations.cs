﻿using System;

namespace lab_4.Models
{
    public class Stations
    {
        public Int32 StationId { get; set; }

        public string Station { get; set; }

        public double Distance { get; set; }

        public double Cost { get; set; }

    }
}

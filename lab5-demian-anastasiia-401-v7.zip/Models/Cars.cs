﻿using System;

namespace lab_4.Models
{
    public class Cars
    {
        public Int32 CarId { get; set; }
        public string Car { get; set; }
        public Int32 TrainId { get; set; }
        public string CarType { get; set; }
        public double ExtraCarFee { get; set; }
    }
}
